package cargovehicles;

public class Ship 
{
	public int weight;

	//no arguement
	public Ship()
	{
		
	}

	//parameterized constructor
	public Ship(int weight)
	{
		this.weight=weight;
	}




	public int getWeight()
	{
	return weight;	
	}
	}
