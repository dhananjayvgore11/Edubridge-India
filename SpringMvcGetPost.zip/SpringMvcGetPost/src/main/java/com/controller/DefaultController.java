package com.controller;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import com.model.Product;

@Controller
public class DefaultController {

	/*//by model 
	 * @RequestMapping(value="/index",method=RequestMethod.GET)
	 * 
	 * public String index_get(Model model) { BeanFactory factory=new
	 * XmlBeanFactory(new ClassPathResource("beans.xml")); Product
	 * product=(Product)factory.getBean("product");
	 * model.addAttribute("requestMethod","through GET method");
	 * model.addAttribute("product",product); return "index"; }
	 */

	//by modelAndView
	/* @GetMapping(value = "/index", method = RequestMethod.GET) */
	
	/*
	 * @GetMapping(value = "/index")
	 *  public ModelAndView index_get(ModelAndView model )
	 */
	
	@GetMapping(value = "/index")
	public ModelAndView index_get(ModelAndView model ) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("beans.xml"));
		Product product = (Product) factory.getBean("product");
		model.addObject("requestMethod", "through GET method");
		model.addObject("product", product);
		model.setViewName("index");
		return model;
	}

	@PostMapping(value = "/hello")
	public String index_post(@ModelAttribute("product") Product product, ModelMap model) {
		model.addAttribute("requestMethod", "through POST method");
		System.out.println("kjhkfsls" + product.getId());
		System.out.println(product.getPrice());
		System.out.println(product.getName());
		return "result";
	}
	
	@GetMapping(value = "/hello1")
	public String index_result(@ModelAttribute("product") Product product, ModelMap model) {
		//model.addAttribute("requestMethod", "through POST method");
		System.out.println("kjhkfsls" + product.getId());
		System.out.println(product.getPrice());
		System.out.println(product.getName());
		return "index";
	}
	

}
