package Salary;
import java.util.*;
import java.lang.*;
public class Salaryperson {
 

static int computeSalary(int basic, char grade)
{
    double allowance;
    double hra, da, pf;
     
    hra = 0.50 * basic;
    da = 0.75 * basic;
    pf = 0.12 * basic;
     
    // Condition to compute the
    // allowance for the person
    if (grade == 'A')
    {
        allowance = 1700;
    }
    else if (grade == 'B')
    {
        allowance = 1500;
    }
    else
    {
        allowance = 1300;
    }
    double gross;
     
    // Calculate gross salary
    gross = Math.round(basic + hra + da +
                         allowance - pf);
                          
    return (int)gross;
}
 
// Driver Code
public static void main (String[] args)
{
    int basic = 10000;
    char grade = 'A';
     
    // Function call
    System.out.println(computeSalary(basic, grade));
}
}