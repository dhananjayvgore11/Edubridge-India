package Unaryoperation;


//public class Main {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//Student student=new Student();//object created
//System.out.println("enter the roll_no");
//System.out.println("enter the marks");
//System.out.println(+15+" "+(+100));//unary plus operator

class Main {

 
 public static void main(String[] args)
 {
     // Initializing variables
////     boolean cond = true;
//        int a = 10, b = 1;
//
//     // Displaying values stored in above variables
//     System.out.println("Cond is: " + cond);
//     System.out.println("Var1 = " + a);
//     System.out.println("Var2 = " + b);
//
//     // Displaying values stored in above variables
//     // after applying unary NOT operator
//     System.out.println("Now cond is: " + !cond);
//     System.out.println("!(a < b) = " + !(a < b));
//     System.out.println("!(a > b) = " + !(a > b));
	 int a=10,b=20;
	 int result = a++ + ++b + --b + b--;
	 //10 + 21 +  20 +20 = 71
	 System.out.println(result);
	 System.out.println(a);
	 System.out.println(b);

	 
 }
}
	



