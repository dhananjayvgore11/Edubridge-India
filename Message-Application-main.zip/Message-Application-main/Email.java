package messanger;

public class Email {
	
	public String receiver, message;

	public Email(String receiver, String message) 
	 {
	     this.receiver = receiver;
	     this.message = message;
	 }

}