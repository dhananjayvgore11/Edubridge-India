package messanger;

public class SmsMessage {
	
	public String receiver, message;

	public SmsMessage(String receiver, String message)
	{
		this.receiver = receiver;
		this.message = message;
	}

}